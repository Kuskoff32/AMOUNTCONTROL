﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.IO.Ports;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Telescop
{
    
    public partial class Form1 : Form
    {
        public SerialPort mySerialPort = new SerialPort();

        public Form1()
        {
            InitializeComponent();
            
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button15_Click(object sender, EventArgs e)
        {
            Com_port newForm = new Com_port();
            newForm.Owner = this;
            newForm.ShowDialog();

            if (textBox4.Text != "")
            {
                mySerialPort.PortName = textBox4.Text;

                mySerialPort.BaudRate = 9600;
                mySerialPort.Parity = Parity.None; // протокол контроля четности
                mySerialPort.WriteTimeout = 50;
                mySerialPort.ReadTimeout = 50;
                //mySerialPort.DataBits = 8;

                // проверить открыт или нет, если нет то открыть
                mySerialPort.Open();

                //

                System.Threading.Thread.Sleep(50);
            }

            // MyFun mf = new MyFun();

                // MessageBox.Show(" Порт № 1 = " + mf.Choice_Com_Port());
        }

        private void button17_Click(object sender, EventArgs e)
        {
            // добавить проверку на имя порта , не д.б. пустым
            if (textBox4.Text != "")
            {
                /*mySerialPort.PortName = textBox4.Text;

                mySerialPort.BaudRate = 9600;
                mySerialPort.Parity = Parity.None; // протокол контроля четности
                mySerialPort.WriteTimeout = 50;
                mySerialPort.ReadTimeout = 50;
                //mySerialPort.DataBits = 8;
                mySerialPort.Open();
                System.Threading.Thread.Sleep(50);
                */
                if (textBox1.Text == "0")
                    mySerialPort.Write("F" + textBox1.Text);
                else
                {
                    mySerialPort.Write("F-" + textBox1.Text);
                    System.Threading.Thread.Sleep(500);
                    mySerialPort.Write("F0");
                }

                // mySerialPort.Close();
            }
            else MessageBox.Show("СОМ-порт не выбран, зайдите в Setup");
        }

        private void button18_Click(object sender, EventArgs e)
        {
            // добавить проверку на имя порта , не д.б. пустым
            if (textBox4.Text != "")
            {
                /*mySerialPort.PortName = textBox4.Text;

                mySerialPort.BaudRate = 9600;
                mySerialPort.Parity = Parity.None; // протокол контроля четности
                mySerialPort.WriteTimeout = 50;
                mySerialPort.ReadTimeout = 50;
                //mySerialPort.DataBits = 8;
                mySerialPort.Open();
                System.Threading.Thread.Sleep(50);
                */
                if (textBox1.Text == "0")
                    mySerialPort.Write("F" + textBox1.Text);
                else
                {
                    mySerialPort.Write("F+" + textBox1.Text);
                    System.Threading.Thread.Sleep(50);
                    mySerialPort.Write("F0");
                }

                // mySerialPort.Close();
            }
            else MessageBox.Show("СОМ-порт не выбран, зайдите в Setup");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Text = "1";
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            textBox1.Text = "2";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Text = "3";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            textBox1.Text = "4";
        }

        private void button5_Click(object sender, EventArgs e)
        {
            textBox1.Text = "5";
        }

        private void button6_Click(object sender, EventArgs e)
        {
            textBox1.Text = "6";
        }

        private void button7_Click(object sender, EventArgs e)
        {
            textBox1.Text = "7";
        }

        private void button8_Click(object sender, EventArgs e)
        {
            textBox1.Text = "8";
        }

        private void button9_Click(object sender, EventArgs e)
        {
            textBox1.Text = "9";
        }

        private void button10_Click(object sender, EventArgs e)
        {
            textBox1.Text = "0";
        }

        private void button11_Click(object sender, EventArgs e)
        {
            // North
            if (textBox4.Text != "")
            {
                /* mySerialPort.PortName = textBox4.Text;

                mySerialPort.BaudRate = 9600;
                mySerialPort.Parity = Parity.None; // протокол контроля четности
                mySerialPort.WriteTimeout = 50;
                mySerialPort.ReadTimeout = 50;
                //mySerialPort.DataBits = 8;
                mySerialPort.Open();
                */
                System.Threading.Thread.Sleep(50);

                mySerialPort.Write("N" + textBox1.Text);

                System.Threading.Thread.Sleep(50);

                mySerialPort.Write("N0");


                //mySerialPort.Close();
            }
        
            else MessageBox.Show("СОМ-порт не выбран, зайдите в Setup");
        }

        private void button12_Click(object sender, EventArgs e)
        {
            //South
            if (textBox4.Text != "")
            {
                /*
                mySerialPort.PortName = textBox4.Text;

                mySerialPort.BaudRate = 9600;
                mySerialPort.Parity = Parity.None; // протокол контроля четности
                mySerialPort.WriteTimeout = 50;
                mySerialPort.ReadTimeout = 50;
                //mySerialPort.DataBits = 8;
                mySerialPort.Open();
                */
                System.Threading.Thread.Sleep(50);

                mySerialPort.Write("S" + textBox1.Text);

                System.Threading.Thread.Sleep(50);

                mySerialPort.Write("S0");

                //mySerialPort.Close();
            }
        
            else MessageBox.Show("СОМ-порт не выбран, зайдите в Setup");
        }

        private void button13_Click(object sender, EventArgs e)
        {
            //Est
            if (textBox4.Text != "")
            {
                /*
                mySerialPort.PortName = textBox4.Text;

                mySerialPort.BaudRate = 9600;
                mySerialPort.Parity = Parity.None; // протокол контроля четности
                mySerialPort.WriteTimeout = 50;
                mySerialPort.ReadTimeout = 50;
                //mySerialPort.DataBits = 8;
                mySerialPort.Open();
                System.Threading.Thread.Sleep(50);
                */

                mySerialPort.Write("E" + textBox1.Text);

                System.Threading.Thread.Sleep(50);

                mySerialPort.Write("E0");

                // mySerialPort.Close();
            }

            else MessageBox.Show("СОМ-порт не выбран, зайдите в Setup");

        }
        private void button14_Click(object sender, EventArgs e)
        {
            //West
            if (textBox4.Text != "")
            {
                /*mySerialPort.PortName = textBox4.Text;

                mySerialPort.BaudRate = 9600;
                mySerialPort.Parity = Parity.None; // протокол контроля четности
                mySerialPort.WriteTimeout = 50;
                mySerialPort.ReadTimeout = 50;
                //mySerialPort.DataBits = 8;
                mySerialPort.Open();
                System.Threading.Thread.Sleep(50);
                */
                mySerialPort.Write("W" + textBox1.Text);

                System.Threading.Thread.Sleep(50);

                mySerialPort.Write("W0");

               // mySerialPort.Close();
            }

            else MessageBox.Show("СОМ-порт не выбран, зайдите в Setup");
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            mySerialPort.Close();
            // MessageBox.Show("СОМ-порт закрыт");
        }
    }
    
}
